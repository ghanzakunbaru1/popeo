module.exports = {
  tokens: "8466467907:AAE7kPk_vGzPoINVQ8SiPbQCE4UycW_GYQg",  // Masukin Bot token kamu
  owners: "7882058841", // Masukin ID Telegram kamu
  port: "1034", // Masukin Port panel kamu 
  ipvps: "http://require.paradoxofmatrix.my.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};